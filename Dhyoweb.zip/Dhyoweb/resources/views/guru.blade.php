@extends('layouts.app')
@section('content')
<div class="container mt-3">
    <h1>Daftar Guru SMKN 2 Trenggalek</h1>
    <ul class="list-group">
        <li class="list-group-item">Ivans Zuwanta</li>
        <li class="list-group-item">Ervi Rahmawati</li>
        <li class="list-group-item">Wahyu Tri Wulansari</li>
        <li class="list-group-item">Novi Dyah Puspitasari</li>
        <li class="list-group-item">Safira Maya Shovie</li>
        <li class="list-group-item">Estri Handayani</li>
        <li class="list-group-item">Fikrotu Dwi Fuudatuzzahro</li>
        <li class="list-group-item">Labib Fayumi</li>
    </ul>
</div>
@endsection