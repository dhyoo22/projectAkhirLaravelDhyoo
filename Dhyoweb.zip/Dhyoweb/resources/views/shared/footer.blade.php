<div class="container">
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <p class="col-md-12 mb-0 text-muted">© 2023 - RPL, SMKN 2 TRENGGALEK </P>
</footer>
</div>